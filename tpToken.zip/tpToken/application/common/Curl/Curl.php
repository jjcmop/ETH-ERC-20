<?php
namespace app\common\Curl;
class Curl{
	//请求https的方法
	public static function https_curl($url,$data=null){
	//初始化curl资源
		$curl=curl_init();
		
		curl_setopt($curl,CURLOPT_URL,$url);
		curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,FALSE);
		if(!empty($data)){
			curl_setopt($curl,CURLOPT_POST,1);
			curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
		}
		curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
		$output=curl_exec($curl);
		curl_close($curl);
		return $output;
	}
	//请求https带头信息
	public static function https_head_curl($url,$data=null,$head=[]){
	//初始化curl资源
		$curl=curl_init();
		
		curl_setopt($curl,CURLOPT_URL,$url);
		if(!empty($head)) curl_setopt($curl, CURLOPT_HTTPHEADER, $head);//定义header
		curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,FALSE);
		if(!empty($data)){
			curl_setopt($curl,CURLOPT_POST,1);
			curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
		}
		curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
		$output=curl_exec($curl);
		curl_close($curl);
		return $output;
	}
	public static function https_json_curl($url,$data=null){
	//初始化curl资源
		$curl=curl_init();
		curl_setopt($curl,CURLOPT_URL,$url);
		curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,FALSE);
		if(!empty($data)){
			curl_setopt($curl,CURLOPT_POST,1);
			curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
			curl_setopt($curl, CURLOPT_HTTPHEADER, array(  
            'Content-Type: application/json; charset=utf-8',  
            'Content-Length: ' . strlen($data)   
            ));
		}
		curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
		$output=curl_exec($curl);
		curl_close($curl);
		return $output;
	}
	public static function https_json_put($url,$data){
	//初始化curl资源
		$curl=curl_init();
		$header[] = "Content-Type: application/json; charset=utf-8";//定义header，可以加多个
		$header[] = 'Content-Length: ' . strlen($data);
		curl_setopt($curl,CURLOPT_URL,$url);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);//定义header
		curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,FALSE);
//		curl_setopt($curl,CURLOPT_POST,1);
		curl_setopt($curl, CURLOPT_HEADER,0); //定义是否显示状态头 1：显示 ； 0：不显示 
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data); //定义提交的数据json_decode($data,true)
		curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
		$output=curl_exec($curl);
		curl_close($curl);
		return $output;
	}
	//请求http的方法
	public static function http_curl($url,$data=null){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		if(!empty($data)){
			curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
			curl_setopt($curl,CURLOPT_POST,1);
			curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$output = curl_exec($curl);
		curl_close($curl);
		if ($output === FALSE){
				return "cURL Error: ". curl_error($curl);
			}
		return $output;
		}
}
