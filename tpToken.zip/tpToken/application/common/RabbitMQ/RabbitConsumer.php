<?php
namespace app\common\RabbitMQ;
use think\Controller;
use think\Model;
use think\db;
use think\Config;
use app\common\RabbitMQ\RabbitPublish;
use app\common\controller\RabbitMQ;
class RabbitConsumer extends Model{
	private $file;

	public function __construct(){
		parent::__construct();
		$this->file = "/tmp/".date("Y-m-d").".md";
	}

	public function amqp_consume_msg_fanout($keyword='test'){
		try{
			$conn = new \AMQPConnection( Config::get('ARG_AMQP') );

			$common = new RabbitMQ();
			$publish = new RabbitPublish();
			$queue = $keyword.'_queue';
			if (!$conn->connect()) {
		        //return array( 'code'=>400,'msg'=>'连接失败','data'=>array() );
		        throw new \Exception('连接失败');
		    }
		    $channel = new \AMQPChannel($conn);
		    $q = new \AMQPQueue($channel);
			$q->setName($queue);
			$q->setFlags(AMQP_DURABLE); //持久化
			$q->declareQueue();
			$q->consume(function($envelope, $queue)use($common,$keyword,$publish) {
				try{
    				$msg = json_decode( $envelope->getBody(),True );
    				switch ($keyword) {
                        case 'return_coin_withdraw':
                        	//设置用户信息
                            $common -> get_return_coin_withdraw($msg);
                            break;
                        case 'coin_recharge':
                        	//设置用户信息
                            $common -> get_coin_recharge($msg);
                            break;
                        case 'batchGetAddress':
                        	$common -> batchGetAddress($msg);
                        	break;      
    					default:
    						break;
    				}
    				$queue->ack($envelope->getDeliveryTag()); //手动发送ACK应答
				}catch(\Exception $e){
					$publish -> amqp_publish_msg_fanout(['msg'=>$e->getMessage()],'tests');
				}
			});
		}catch( \Exception $e ){
			$conn->disconnect();
			throw $e;
		}
	}
	public function amqpGetMsgFanout($keyword='test'){
		try{
			$conn = new \AMQPConnection( Config::get('ARG_AMQP') );
			$common = new RabbitMQ();
			$queue = $keyword.'_queue';
			if (!$conn->connect()) {
		        //return array( 'code'=>400,'msg'=>'连接失败','data'=>array() );
		        throw new \Exception('连接失败');
		    }
		    $channel = new \AMQPChannel($conn);
		    $q = new \AMQPQueue($channel);
			$q->setName($queue);
			$q->setFlags(AMQP_DURABLE); //持久化
			$q->declareQueue();
			$env = $q->get();
			if($env){
				$data = $env->getBody();
				$msg = json_decode( $data,True );
				switch($keyword){
					case 'return_coin_withdraw':
		            	//发送提现订单广播
		                $common -> get_return_coin_withdraw($msg);
		                break;
           			case 'coin_recharge':
		            	//发送充值订单广播
		                $common -> get_coin_recharge($msg);
		                break;
		            case 'agentNotionalPooling':
		            	//商户手动归集
		            	$common -> agentNotionalPooling($msg);
		            	break;  
		            case 'batchGetAddress':
                    	$common -> batchGetAddress($msg);
                    	break; 
                    case 'coin_withdraw':
                    	$common -> coinWithdraw($msg);
        	     	  	break;    	     	  
	    			default:
	    				break;
				}
				$q->ack($env->getDeliveryTag());
			}
			$conn->disconnect();
		}catch( \Exception $e ){
			$conn->disconnect();
			throw $e;
		}
	}
}