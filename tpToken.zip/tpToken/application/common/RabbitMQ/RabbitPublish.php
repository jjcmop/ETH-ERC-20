<?php
namespace app\common\RabbitMQ;
use think\Controller;
use think\Model;
use think\db;
use think\Config;
class RabbitPublish extends Model{
	//private $conn;
	public function __construct(){

	}
	//direct交换器
	public function amqpPublishMsgFanout($msg,$keyword='test'){
		try{
			$conn = new \AMQPConnection( Config::get('ARG_AMQP') );
			$exchange = $keyword.'_fanout_exchange';
			$queue = [$keyword.'_queue'];
			//创建连接和channel
	        if(!is_string($msg)){
	            $msg = json_encode($msg);
	        }else{
	        	$msg_arr = ['msg'=>$msg];
	        	$msg = json_encode($msg);
	        }
	        if (!$conn->connect()) {
	        	throw new \Exception('连接失败');
	        }
	        $channel = new \AMQPChannel($conn);
	        //创建交换机
	        $ex = new \AMQPExchange($channel);
	        $ex->setName($exchange);
	        $ex->setType(AMQP_EX_TYPE_FANOUT); //direct类型
	        $ex->setFlags(AMQP_DURABLE); //持久化
	        //$ex->setFlags(AMQP_PASSIVE); //已存在抛出异常
	        $ex->declareExchange();
	        foreach($queue as $k => $v){
	        	//创建队列
		        $q = new \AMQPQueue($channel);
		        $q->setName($v);
		        $q->setFlags(AMQP_DURABLE); //持久化
		        $q->declareQueue();
		        $q->bind($exchange);
	        }
	        $ex->publish($msg);
		}catch(\Exception $e){
			$conn->disconnect();
			throw $e;
		}
	}
	//direct交换器
	public function amqp_publish_msg_fanout($msg,$keyword='test'){
		try{
			$conn = new \AMQPConnection( Config::get('ARG_AMQP') );
			$exchange = $keyword.'_fanout_exchange';
			$queue = [$keyword.'_queue'];
			//创建连接和channel
	        if(!is_string($msg)){
	            $msg = json_encode($msg);
	        }else{
	        	$msg_arr = ['msg'=>$msg];
	        	$msg = json_encode($msg);
	        }
	        if (!$conn->connect()) {
	            return array( 'code'=>400,'msg'=>'连接失败','data'=>array() );
	        }
	        $channel = new \AMQPChannel($conn);
	 
	        //创建交换机
	        $ex = new \AMQPExchange($channel);
	        $ex->setName($exchange);
	        $ex->setType(AMQP_EX_TYPE_DIRECT); //direct类型
	        $ex->setFlags(AMQP_DURABLE); //持久化
	        //$ex->setFlags(AMQP_PASSIVE); //已存在抛出异常
	        $ex->declareExchange();
	        // $ex->declare($exchange, AMQP_EX_TYPE_FANOUT, AMQP_DURABLE | AMQP_AUTODELETE);
	        foreach($queue as $k => $v){
	        	//创建队列
		        $q = new \AMQPQueue($channel);
		        $q->setName($v);
		        $q->setFlags(AMQP_DURABLE); //持久化
		        $q->declareQueue();
		        $q->bind($exchange);
	        }
	        $ex->publish($msg);
	        return array( 'code'=>200,'msg'=>'发送成功','data'=>array() );
		}catch(\Exception $e){
			$conn->disconnect();
			return array( 'code'=>400,'msg'=>$e->getMessage(),'data'=>array() );
		}
	}

		//direct交换器
	public function amqp_publish_money_fanout($msg,$keyword='test'){
		try{
			$conn = new \AMQPConnection( Config::get('ARG_AMQP') );
			$exchange = $keyword.'_fanout_exchange';
			$queue = [$keyword.'_eth_queue'];
			//创建连接和channel
	        if(!is_string($msg)){
	            $msg = json_encode($msg);
	        }else{
	        	$msg_arr = ['msg'=>$msg];
	        	$msg = json_encode($msg);
	        }
	        if (!$conn->connect()) {
	            return array( 'code'=>400,'msg'=>'连接失败','data'=>array() );
	        }
	        $channel = new \AMQPChannel($conn);
	        //创建交换机
	        $ex = new \AMQPExchange($channel);
	        $ex->setName($exchange);
	        $ex->setType('fanout'); //direct类型
	        $ex->setFlags(2); //持久化
	        //$ex->setFlags(AMQP_PASSIVE); //已存在抛出异常
	        $ex->declareQueue();
	        foreach($queue as $k => $v){
	        	//创建队列
		        $q = new \AMQPQueue($channel);
		        $q->setName($v);
		        $q->setFlags(2); //持久化
		        $q->declareQueue();
		        $q->bind($exchange);
	        }
	        $ex->publish($msg);
	        return array( 'code'=>200,'msg'=>'发送成功','data'=>array() );
		}catch(\Exception $e){
			$conn->disconnect();
			return array( 'code'=>400,'msg'=>$e->getMessage(),'data'=>array() );
		}
	}

	/*public function __destruct(){
		$this->conn->disconnect();
	}*/
}