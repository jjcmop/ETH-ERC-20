<?php
namespace app\common\controller;
use think\Controller;
use app\common\Mapi\Walletadd;
use think\Db;
use app\common\RabbitMQ\RabbitPublish;
/**
 * 
 */
class Tokenlist extends Controller
{
	public function __construct(){
		parent::__construct();
		$this->Mapi = new Walletadd();
		$this->publish = new RabbitPublish();
	}

	/**
	*	钱包转入数据获取
	*
	**/
	public function coin_order_info($coinData){
		Db::startTrans();
		try {
			$Height = $coinData['Height'];
			if($coinData['type'] == 'eth'){
				$data = $this->Mapi->coinRecharge($Height);
				$message = $data;
				file_put_contents('/tmp/coin/coin_order_info.log',date("Y-m-d H:i:s",time()).',ETH->'.$Height.',Data:'.json_encode($message)."\n",FILE_APPEND|LOCK_EX);
			}
			if(!$data){ 
				return ['status'=>400,'msg'=>'数据获取失败'];
			}
			if($data['status'] == 200){
				if(!empty($data['data'])){
					// file_put_contents('/tmp/coin/coin_order_success.log',date("Y-m-d H:i:s",time()).',ETH->'.$Height.',Data:'.json_encode($message)."\n",FILE_APPEND|LOCK_EX);
					$result = $data['data'];
				 	foreach ($result as $key => $val) {
				 		$User = Db::name('user_coin')->where([$val['type'].'b' => $val['user_addr']])->field('id,username,agent_id')->find();
				 		if(!empty($User)){
				 			$order = Db::name('myzr')->where(['hash' => $val['hash']])->find();
				 			if(!empty($order)){
				 				continue;
				 			}
				 			$addData = [
				 				'userid'       =>  	$User['id'],
				 				'username'     =>	$User['username'],
				 				'coinname'     =>	$val['type'],
				 				'from_address' =>	$val['from_addr'],
				 				'to_address'   =>	$val['user_addr'],
				 				'num'          =>	$val['num'],
				 				'fee'		   =>	0,
				 				'mum'          =>	$val['num'],
				 				'addtime'      =>   time(),
				 				'endtime'	   =>   0,
				 				'status'       =>   1,
				 				'block_number' =>   $val['block_number'],
				 				'hash'         =>   $val['hash'],
				 				'agent_id'     =>   $User['agent_id'],
				 				'common'       =>  '提现成功'
				 			];
				 			$zrID = Db::name('myzr')->insertGetId($addData);
				 			Db::name('user_coin')->where([$val['type'].'b' => $val['user_addr']])->setInc($val['type'],$val['num']);
				 			$pushData = Db::name("myzr")->alias("m")->join("coin c","c.agent_id = m.agent_id AND c.name = m.coinname")->field("m.id,m.to_address as address,m.num,m.addtime as createtime,m.block_number as blockNumber,m.hash,CONCAT(UPPER(c.coin_type),'_',UPPER(c.name),'_',c.token_user) as coin_type,'in' as direction,m.status,m.common")->where(['m.id' => $zrID])->find();
				 			$this->publish->amqp_publish_msg_fanout($pushData,"coin_recharge");
				 		}
				 	}
				}
				Db::commit();
				return ['status'=>200,'msg'=>'更新交易成功！','data'=>''];
			}else{
				if($coinData['type'] == 'eth'){
					$block_num = $Height;
					//钱包高度超过时 获取最新高度
					if(in_array($data['status'], [401])){
						$block_num = $data['json'];
					}
					//钱包返回错误时 修改钱包api状态 停止获取接口 避免消息队列累积
					Db::name('coin')->where(['type'=>'eth'])->update(['api_status'=>1,'err_time'=>time(),'block_num'=>$block_num]);
				}
				Db::commit();
				return ['status'=>400,'msg'=>json_encode($data)];
			}
		} catch (\Exception $e) {
			Db::rollback();
			return ['status'=>400,'msg'=>$e->getMessage().'->'.$e->getline()];
		}
	}

	/**
	 * 	单独高度订单获取
	 * 
	 */
	public function BlockNumberToOrder($coinData){
		Db::startTrans();
		try{
			$Height = $coinData['Height'];
			if($coinData['type'] == 'eth'){
				$data = $this->Mapi->coinRecharge($Height);
				$message = $data;
				file_put_contents('/tmp/coin/BlockNumberToOrder.log',date("Y-m-d H:i:s",time()).',ETH->'.$Height.',Data:'.json_encode($message)."\n",FILE_APPEND|LOCK_EX);
			}
			if(!$data){ 
				return ['status'=>400,'msg'=>'数据获取失败'];
			}
			if($data['status'] == 200){
				if(!empty($data['data'])){
					$result = $data['data'];
				 	foreach ($result as $key => $val) {
				 		$User = Db::name('user_coin')->where([$val['type'].'b' => $val['user_addr']])->field('id,username,agent_id')->find();
				 		if(!empty($User)){
				 			$order = Db::name('myzr')->where(['hash' => $val['hash']])->find();
				 			if(!empty($order)){
				 				continue;
				 			}
				 			$addData = [
				 				'userid'       =>  	$User['id'],
				 				'username'     =>	$User['username'],
				 				'coinname'     =>	$val['type'],
				 				'from_address' =>	$val['from_addr'],
				 				'to_address'   =>	$val['user_addr'],
				 				'num'          =>	$val['num'],
				 				'fee'		   =>	0,
				 				'mum'          =>	$val['num'],
				 				'addtime'      =>   time(),
				 				'endtime'	   =>   0,
				 				'status'       =>   1,
				 				'block_number' =>   $val['block_number'],
				 				'hash'         =>   $val['hash'],
				 				'agent_id'     =>   $User['agent_id']
				 			];
				 			$zrID = Db::name('myzr')->insertGetId($addData);
				 			Db::name('user_coin')->where([$val['type'].'b' => $val['user_addr']])->setInc($val['type'],$val['num']);
				 			$pushData = Db::name("myzr")->alias("m")->join("coin c","c.agent_id = m.agent_id AND c.name = m.coinname")->field("m.id,m.to_address as address,m.num,m.addtime as createtime,m.block_number as blockNumber,m.hash,CONCAT(UPPER(c.coin_type),'_',UPPER(c.name),'_',c.token_user) as coin_type,'in' as direction")->where(['m.id' => $zrID])->find();
				 			$this->publish->amqp_publish_msg_fanout($pushData,"coin_recharge");
				 		}
				 	}
				}
				Db::commit();
				return ['status'=>200,'msg'=>'更新交易成功！','data'=>''];
			}
		}catch(\Exception $e){
			Db::rollback();
			return ['status'=>400,'msg'=>$e->getMessage().'->'.$e->getline()];
		}
	}
}