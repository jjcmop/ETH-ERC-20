<?php
namespace app\common\controller;
use think\Controller;
use think\Db;
use app\common\Curl\Curl;
use app\common\Mapi\Walletadd;
use think\Config;
use app\common\Ext\EthClient;
use app\common\RabbitMQ\RabbitPublish;
use app\common\controller\RedisLib;
/**
 *  处理消息队列内容
 *  by LaoHu 2019-11-5
 * 
 */
	
class RabbitMQ extends Controller{
	private $returnUrl = "";
	public function __construct(){
		parent::__construct();
		$this->returnUrl = "http://token.xcoinpay.io/Api/Payeth/callback";
	}
	//提现订单广播
	public function get_return_coin_withdraw($data){
		try{
			if(!empty($data)){
				$id = $data['id'];
				unset($data['id']);
				$result = Curl::http_curl($this->returnUrl,$data);
				$returnData = json_decode($result,true);
				if(isset($returnData['code'])){
					Db::name("myzc")->where(['id' => $id])->update(['is_return' => 1]);
				}
			}
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/get_return_coin_withdraw.log', date("Y-m-d H:i:s",time())."-->RabbitMQ:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
	//充值订单广播
	public function get_coin_recharge($data){
		try{
			if(!empty($data)){
				$id = $data['id'];
				unset($data['id']);
				$result = Curl::http_curl($this->returnUrl,$data);
				$returnData = json_decode($result,true);
				if(isset($returnData['code'])){
					Db::name("myzr")->where(['id' => $id])->update(['is_return' => 1]);
				}
			}
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/get_coin_recharge.log', date("Y-m-d H:i:s",time())."-->RabbitMQ:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
	//商户手动归集
	public function agentNotionalPooling($data){
		try{
			if(empty($data)){
				throw new \Exception('用户数据异常');
			}
			if(!in_array($data['coin'],['eth','usdt','dyx'])){
				throw new \Exception('无效的币种系列');
			}
			$message = '';
			$success = 0;
			//计算商户主地址手续费
			$Mapi = new walletAdd();
			$result = $Mapi->getAgentBalance('eth',$data['agentAddr']);
			$Coin = Config::get('COIN');
			$CoinClient = new EthClient($Coin['eth']['dj_zj'], $Coin['eth']['dj_dk']);
            //获取钱包高度
            $json = $CoinClient->eth_blockNumber(true);

            if (empty($json) || $json <= 0) {
                return ['status' => 402, 'message' => '钱包连接失败！'];
            }
			if($result['status'] == 200){
				//查询子地址账户余额
				$userCoinRes = $Mapi->getAgentBalance($data['coin'],$data['userAddr']);
				$userCoin = $userCoinRes['sum'];
				if($data['coin'] == 'eth'){
					//子地址账户eth余额大于0.5时归集
					if($userCoin > 0.5){
						$tradeInfo = [[
                            'from' => $data['userAddr'],
                            'to' => $data['agentAddr'],
                            'value' => $CoinClient->encode_dec($CoinClient->to_real_value(floatval( $userCoin - 0.002))),
                        ]];
                        $sendrs = $CoinClient->eth_sendTransaction($data['userAddr'], md5($data['userPass'].'token') , $tradeInfo);
                        if(isset($sendrs->error)){
                        	$message = $sendrs->error;
                        }else{
                        	$success = 1;
                        }
					}else{
						$message = 'ETH账户余额少于0.5不做归集处理';
					}

				}else{
					$agentEth = $result['sum'];
					if($agentEth < 0.02){
						$message = '商户主地址手续费余额不足!';
					}else{
						if($userCoin > 0){
							//查询子地址eth账户余额 少于0.002的 将由主账户补与
							$userEthRes = $Mapi->getAgentBalance('eth',$data['userAddr']);
							$userEth = $userEthRes['sum'];
							//子地址账户手续费余额不足时主账户转入
							if($userEth < 0.002){
								$tradeInfo = [[
	                                'from' => $data['agentAddr'],
	                                'to' => $data['userAddr'],
	                                'gas' => '0x76c0',
	                                'value' => $CoinClient->encode_dec($CoinClient->to_real_value(floatval(0.002 - $userEth))),
	                                'gasPrice' => $CoinClient->eth_gasPrice()
	                            ]];
	                            $sendrs = $CoinClient->eth_sendTransaction($data['agentAddr'], md5($data['agentPass'].'token'), $tradeInfo);
							}
							//检查 手续费转账是否错误
							if(isset($sendrs->error)){
								$message = $sendrs->error;
							}
							//将子账户代币余额归集到主账户
	                        $call = [
	                            'to' => $Coin[$data['coin']]['token_address'],
	                            'data' => '0x70a08231' . $CoinClient->data_pj($data['userAddr'])
	                        ];
	                        $num_token = $CoinClient->eth_call($call);
	                        $tradeInfo = [[
	                            'from' => $data['userAddr'],
	                            'to' => $Coin[$data['coin']]['token_address'],
	                            'data' => '0xa9059cbb' . $CoinClient->data_pj($data['agentAddr'], $num_token),
	                        ]];
	                        $sendrs = $CoinClient->eth_sendTransaction($data['userAddr'],md5($data['userPass'].'token') , $tradeInfo);
	                        if(isset($sendrs->error)){
	                        	$message = $sendrs->error;
	                        }else{
	                        	$success = 1;
	                        }
                        }
					}
				}
				if($userCoin > 0){
					$installData = [
						'agent_log' => $data['log_id'],
						'coinname'	=> $data['coin'],
						'address' 	=> $data['userAddr'],
						'status'	=> $success,
						'common' 	=> $message,
						'sum'		=> $userCoin,
						'addtime' 	=> time()
					];
					Db::name("agent_gj_log")->insert($installData);
				}
			}else{
				throw new \Exception('主地址ETH余额查询失败');
			}
	
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/agentNotionalPooling.log', date("Y-m-d H:i:s",time())."-->RabbitMQ:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}

	//批量生成用户地址
	public function batchGetAddress($data){
		try{
			$url = 'http://token.huziru.com/api/Tokenapi/getUserAddress';
			$result = Curl::https_json_put($url,json_encode($data));

			file_put_contents('/tmp/coin/batchGetAddress.log', date("Y-m-d H:i:s",time()).'-->'.json_encode($result)."\n\n",FILE_APPEND|LOCK_EX);

		}catch(\Exception $e){
			file_put_contents('/tmp/coin/batchGetAddress_err.log', date("Y-m-d H:i:s",time())."-->RabbitMQ:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
	//用户提现处理
	public function coinWithdraw($data){
		Db::startTrans();
		try{
			if(empty($data)){
				throw new \Exception('用户数据异常');
			}
			if(!in_array($data['coin'],['eth','usdt','dyx'])){
				throw new \Exception('无效的币种系列');
			}
			//检查订单是否处理过
			$redislib = new RedisLib();
			$is_check = $redislib->hExists('coin_withdraw',$data['serialNumber']);
			if(!$is_check){
				throw new \Exception('无效的提现订单');
			}
			$message = '';
			$status	= 0;
			$txid = 'null';
			$dataArr = [
                'userid'        =>  $data['user_id'],
                'serial_number' =>  $data['serialNumber'],
                'username'      =>  $data['username'],
                'coinname'      =>  $data['coin'],
                'from_address'  =>  $data['from_addr'],
                'to_address'    =>  $data['to_addr'],
                'num'           =>  $data['num'],
                'fee'           =>  0,
                'mum'           =>  $data['num'],
                'addtime'       =>  time(),
                'endtime'       =>  time(),
                'status'        =>  $status,
                'txid'          =>  $txid,
                'agent_id'      =>  $data['agent_id'],
                'common'		=>  $message
            ];
            $zrID = Db::name('myzc')->insertGetId($dataArr);
            $publish = new RabbitPublish();
			if($zrID){
				//钱包转币操作
	            $Mapi = new walletAdd();
	            $result = $Mapi->coinWithdraw($data['coin'],$data['to_addr'],$data['num'],$data['agent_id']);
	            if($result['status'] == 200){
	                $apiData = $result['sendrs'];
	                if ((isset($apiData->status) && ($apiData->status == 0)) || isset($apiData->error)) {
	                	$message = $apiData->error->message;
	                }else{
	                	$message = '提现成功';
	                	$status	= 1;
	                	$txid = $apiData->result;
	                	Db::name('user_coin')->where([$data['coin'].'b' => $data['from_addr']])->setDec($data['coin'],$data['num']);
	                }        
	            }else{
	                $message = $result['message'];
	            }
	            Db::name('myzc')->where(['id' => $zrID])->update(['status' => $status,'txid' => $txid,'common' => $message]);
	            $pushData = Db::name("myzc")->alias("m")->join("coin c","c.agent_id = m.agent_id AND c.name = m.coinname")->field("m.id,m.serial_number as serialNumber,m.serial_number as uniquekey,m.coinname,m.addtime as createtime,m.num,m.txid,m.to_address as address,CONCAT(UPPER(c.coin_type),'_',UPPER(c.name),'_',c.token_user) as coin_type,'out' as direction,m.status,m.common")->where(['m.id' => $zrID])->find();
	            
	            $publish->amqp_publish_msg_fanout($pushData,"return_coin_withdraw");
	            $redislib->hdel('coin_withdraw',$data['serialNumber']);
	            Db::commit();
			}else{
				file_put_contents('/tmp/coin/rabbitCoinWithdraw_err.log', date("Y-m-d H:i:s",time())."-->order:".$data['serialNumber']."-->data:".json_encode($data)."\n\n",FILE_APPEND|LOCK_EX);
				//失败后重新发起交易
				$publish->amqp_publish_msg_fanout($data,"coin_withdraw");
				Db::commit();
			}       
		}catch(\Exception $e){
			Db::rollback();
			file_put_contents('/tmp/coin/coinWithdraw_err.log', date("Y-m-d H:i:s",time())."-->RabbitMQ:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline().',data:'.json_encode($data)."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
}