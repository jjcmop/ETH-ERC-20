<?php
/**
 * Created by PhpStorm.
 * User: Slagga
 * Date: 10/27/2017
 * Time: 12:08 PM
 */

namespace app\common\Mapi;
use think\Controller;
class Mapi extends Controller
{
    protected function _empty() {
        send_http_status(404);
        $this->json(['status' => 404, 'message' => '模块不存在！']);
    }

    //auth
    protected function auth($type = 'get')
    {
        //request auth
        if($_SERVER['REQUEST_METHOD'] !== strtoupper($type)){
            $this->json(['status' => 201, 'message' => '无效的请求类型！']);
        }

        //ip auth
        $ip = $this->get_client_ip();
        if(!in_array($ip, $this->ip)){
            $this->json(['status' => 202, 'message' => '无效的IP地址！']);
        }

        //count auth
        $data = S($ip);
        if(!$data){
            $data = ['ip' => $ip, 'count' => 1];
            S($ip, $data, 60);
        } else {
            $data = ['ip' => $ip, 'count' => ++$data['count']];
            S($ip, $data, 60);
        }

        if($data['count'] > 60){
            $this->json(['status' => 203, 'message' => '接口访问超过限制！']);
        }
    }

    //json
    protected function json($data = [])
    {
        exit(json_encode($data));
    }

       /**
     * 获取客户端IP地址
     * @param integer $type 返回类型 0 返回IP地址 1 返回IPV4地址数字
     * @param boolean $adv 是否进行高级模式获取（有可能被伪装）
     * @return mixed
     */
    function get_client_ip($type = 0, $adv = false)
    {
        $type      = $type ? 1 : 0;
        static $ip = null;
        if (null !== $ip) {
            return $ip[$type];
        }

        if ($adv) {
            if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
                $pos = array_search('unknown', $arr);
                if (false !== $pos) {
                    unset($arr[$pos]);
                }

                $ip = trim($arr[0]);
            } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (isset($_SERVER['REMOTE_ADDR'])) {
                $ip = $_SERVER['REMOTE_ADDR'];
            }
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        // IP地址合法验证
        $long = sprintf("%u", ip2long($ip));
        $ip   = $long ? array($ip, $long) : array('0.0.0.0', 0);
        return $ip[$type];
    }

    //obj转array
    function object_array($array) {
        if(is_object($array)) {
            $array = (array)$array;
        }
        if(is_array($array)) {
            foreach($array as $key=>$value) {
                $array[$key] = $this->object_array($value);
            }
        }
        return $array;
    }
}

?>