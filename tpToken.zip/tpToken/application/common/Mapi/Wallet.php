<?php
namespace app\common\Mapi;
use think\Controller;
//1. 项目依赖
use BitWasp\Bitcoin\Bitcoin;
use BitWasp\Bitcoin\Crypto\Random\Random;
use BitWasp\Bitcoin\Key\Factory\HierarchicalKeyFactory;
use BitWasp\Bitcoin\Mnemonic\Bip39\Bip39Mnemonic;
use BitWasp\Bitcoin\Mnemonic\Bip39\Bip39SeedGenerator;
use BitWasp\Bitcoin\Mnemonic\MnemonicFactory;
use Web3p\EthereumUtil\Util;
use Web3\Web3;
use My\DataReturn;
use app\common\Mapi\Walletadd;
class Wallet extends controller{

	protected $password = 'Yunfan';

	public function createAddress(){
		try{
			$coinData = [];
	    	// Bip39
			$math = Bitcoin::getMath();
			$network = Bitcoin::getNetwork();
			$random = new Random();
			// 生成随机数(initial entropy)
			$entropy = $random->bytes(Bip39Mnemonic::MIN_ENTROPY_BYTE_LEN);
	        $bip39 = MnemonicFactory::bip39();
	        // 通过随机数生成助记词
	        $mnemonic = $bip39->entropyToMnemonic($entropy);
	        //3. 助记词产生主私钥和主公钥
			$seedGenerator = new Bip39SeedGenerator();
			// 通过助记词生成种子，传入可选加密串'xcoinpay'
			$seed = $seedGenerator->getSeed($mnemonic, $this->password);
			// $coinData['seed'] = $seed->getHex();
			$hdFactory = new HierarchicalKeyFactory();
			$master = $hdFactory->fromEntropy($seed);
			$util = new Util();
			//生成ETH热钱包
			$hardened = $master->derivePath("44'/60'/1'/0/0");
			// $coinData['path'] = "M/44'/60'/1'/0/0";
			$coinData['publicKey'] = $hardened->getPublicKey()->getHex();
			$coinData['privateKey'] = $hardened->getPrivateKey()->getHex();
			// $coinData['address'] = $util->publicKeyToAddress($util->privateKeyToPublicKey($hardened->getPrivateKey()->getHex()));
			$coinData['mnemonic'] = preg_replace("/(\n)|(\s)|(\t)|(\')|(')|(，)/", ',', $mnemonic);
			$coinData['password'] = md5($mnemonic);
			if(!empty($coinData)){
				$Mapi = new walletAdd();
				$result = $Mapi->importPrivateKey($coinData['privateKey'],md5($password.'token'));
				if($result['status'] == 200){
					$coinData['address'] = $result['data'];
					return ['status' => 200,'message' => 'success','data' => json_encode($coinData)];
				}
			}else{
				return ['status' => 400,'message' => '地址生成失败'];
			}
		}catch(\Exception $e){
			DataReturn::returnJson(400,$e->getMessage());
		}
	}
}