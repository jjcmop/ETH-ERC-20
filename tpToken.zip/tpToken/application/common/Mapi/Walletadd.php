<?php
namespace app\common\Mapi;
use app\common\Ext\EthClient;
use My\DataReturn;
use think\Db;
use think\Config;
class walletAdd extends Mapi
{

    protected $ip = ['127.0.0.1','172.16.0.6'];

    protected $gjdz = '0x5979Bfe1d23C383a2858BB35ba116BE12010F354';
     
    protected $Coin = [];

    public function __construct(){
        $this->Coin = Config::get('COIN');
    }

    //生成用户秘钥
    public function getUserAddress($coin,$username){
            //获取代币信息
            $Coin = $this->Coin[$coin];
            //以太坊
            if($Coin['type'] == 'eth'){
                //连接以太坊钱包
                $CoinClient = new EthClient($Coin['dj_zj'], $Coin['dj_dk']);
                //获取以太坊钱包高度
                $json = $CoinClient->eth_blockNumber(true);
                // DataReturn::returnJson(400,$json);
                if (empty($json) || $json <= 0) {
                    return ['status'=> 402, 'message' => '钱包连接失败！'];
                }
                //生成用户钱包秘钥
                $dj_password = md5($username.'token');

                $qianbao = $CoinClient->personal_newAccount($dj_password);
                //返回
                if (!$qianbao) {
                    return ['status'=> 403, 'message' => '生成钱包地址出错1！'];
                }
                return ['status'=> 200, 'message' => '生成钱包地址成功！','qianbao' => $qianbao];
            }else{
                return ['status'=> 400, 'message' => '无效的钱包系列'];
            }
    }

    //ETH代币转入 设置定时任务做轮询查询
    public function coinRecharge($qb_gd){
            //获取ETH代币信息
            $Coin = $this->Coin['eth'];
            //连接钱包服务器
            $CoinClient = new EthClient($Coin['dj_zj'], $Coin['dj_dk']);
            //获取以太坊高度
            $json = $CoinClient->eth_blockNumber(true);

            if ($qb_gd > $json) {
                return ['status' => 401, 'message' => '高度太高，无法轮询。', 'data' => '' , 'json'=>$json];
            }

            if (empty($json) || $json <= 0) {
                return ['status' => 402, 'message' => '钱包连接失败', 'data' => ''];
            }
            //获取节点内转入数据列表
            $listtransactions = $CoinClient->listLocal($qb_gd,$json);
            if (empty($listtransactions)) {
                return ['status' => 200, 'message' => '无轮训交易', 'data' => '' , 'json'=>$json];
            }
            //获取用户ETH地址列表
            // $dz_arr = $CoinClient->eth_accounts();

            // $leng = count($dz_arr);

            $data = [];
            $message = '';
            //轮循节点内转入数据列表
            foreach ($listtransactions as $trans) {
                if (!$trans->to) {
                    continue;
                }
                //判断ETH地址
                if ($trans->input == '0x') {
                    //循环判断用户地址和转入地址
                    // if(in_array($trans->to,$dz_arr)){
                        //获取转入地址属于哪个商户 将余额归集到商户
                    $userData = Db::name('user_coin')->field("agent_id,ethp")->where(['ethb' => $trans->to])->find();
                    if(!empty($userData)){
                        $agentData = Db::name('coin')->field('token_user,token_pass')->where(['name' => 'eth','agent_id' => $userData['agent_id']])->find();
                        //查询到商户主地址时转入主地址 否则转入钱包主地址
                        $agentAdd = !empty($agentData['token_user']) ? $agentData['token_user'] : $this->Coin['eth']['dj_yh'];
                        $agentPwd = !empty($agentData['token_pass']) ? $agentData['token_pass'] : $this->Coin['eth']['dj_mm'];

                        $true_amount = $CoinClient->real_banlance($CoinClient->decode_hex($trans->value));
                        //区分判断手续费转账
                        if($true_amount > 0.002){
                            $zr_info['from_addr'] = $trans->from;
                            $zr_info['user_addr'] = $trans->to;
                            $zr_info['block_number'] = $qb_gd;
                            $zr_info['num'] = $true_amount;
                            $zr_info['hash'] = $trans->hash;
                            $zr_info['type'] = 'eth';
                            array_push($data, $zr_info);

                            //转入数据自动归集到主账户
                            if($trans->to != $agentAdd){
                                $tradeInfo = [[
                                    'from' => $trans->to,
                                    'to' => $agentAdd,
                                    'value' => $CoinClient->encode_dec($CoinClient->to_real_value(floatval( $zr_info['num'] - 0.002))),
                                ]];
                                $sendrs = $CoinClient->eth_sendTransaction($trans->to, md5($userData['ethp'].'token') , $tradeInfo);
                                if(isset($sendrs->error)){
                                    $message .= "ETH归集失败：".$sendrs->error->message;
                                }
                            }
                        }
                    }
                    // }
                }elseif (strlen($trans->input) == 138 && $trans->to == '0xdac17f958d2ee523a2206206994597c13d831ec7') {
                    $value = substr($trans->input, 74, 64);
                    $to = "0x" . substr($trans->input, 34, 40);
                    //按事务散列返回事务的接收。
                    $sts = $CoinClient->eth_getTransactionReceipt($trans->hash);
                    $sts_s = $this->object_array($sts);
                    $sts = substr($sts_s['status'], 2, 1);
                    //判断区块上面的转入状态,status = 0 失败,  logs为空 失败
                    if ($sts != 1 || !$sts_s['logs']) {
    //                    echo 'fail' . "<br>";
                        continue;
                    }
                    // if(in_array($to,$dz_arr)){
                        $userData = Db::name('user_coin')->field("agent_id,ethp")->where(['usdtb' => $to])->find();
                        if(!empty($userData)){
                            $true_amount = $CoinClient->real_banlance_token($CoinClient->decode_hex($value), 6);
                            $zr_info['from_addr'] = $trans->from;
                            $zr_info['user_addr'] = $to;
                            $zr_info['block_number'] = $qb_gd;
                            $zr_info['num'] = $true_amount;
                            $zr_info['hash'] = $trans->hash;
                            $zr_info['type'] = 'usdt';
                            array_push($data, $zr_info);
                            //取出子地址所属商户
                            
                            $agentData = Db::name('coin')->field('token_user,token_pass')->where(['name' => 'eth','agent_id' => $userData['agent_id']])->find();
                            //查询到商户主地址时转入主地址 否则转入钱包主地址
                            $agentAdd = !empty($agentData['token_user']) ? $agentData['token_user'] : $this->Coin['eth']['dj_yh'];
                            $agentPwd = !empty($agentData['token_pass']) ? $agentData['token_pass'] : $this->Coin['eth']['dj_mm'];
                            if($to != $agentAdd){
                                //查询自地址账户eth余额
                                $yue = $CoinClient->eth_getBalance($to);
                                //账户余额少于0.002时 从主账户转入少量ETH作为手续费
                                if ($yue < floatval('0.002')) {
                                    //eth转账到token的eth手续费
                                    $tradeInfo = [[
                                        'from' => $agentAdd,
                                        'to' => $to,
                                        'gas' => '0x76c0',
                                        'value' => $CoinClient->encode_dec($CoinClient->to_real_value(floatval(0.002 - $yue))),
                                        'gasPrice' => $CoinClient->eth_gasPrice()
                                    ]];
                                    $sendrs = $CoinClient->eth_sendTransaction($agentAdd, md5($agentPwd.'token'), $tradeInfo);
                                    if(isset($sendrs->error)){
                                        $message .= "ETH手续费转账失败：".$sendrs->error->message;
                                    }
                                }
                                //将子账户代币余额归集到主账户
                                $call = [
                                    'to' => '0xdac17f958d2ee523a2206206994597c13d831ec7',
                                    'data' => '0x70a08231' . $CoinClient->data_pj($to)
                                ];
                                $num_token = $CoinClient->eth_call($call);
                                $tradeInfo = [[
                                    'from' => $to,
                                    'to' => '0xdac17f958d2ee523a2206206994597c13d831ec7',
                                    'data' => '0xa9059cbb' . $CoinClient->data_pj($this->gjdz, $num_token),
                                ]];
                                $sendrs = $CoinClient->eth_sendTransaction($to,md5($userData['ethp'].'token') , $tradeInfo);
                                if(isset($sendrs->error)){
                                    $message .= "USDT归集失败：".$sendrs->error->message;
                                }
                            }
                        }
                    // }
                }elseif (strlen($trans->input) == 138 && $trans->to == '0x042f972ac93404f0fcbe4e3a0729f0b395232106') {
                    $value = substr($trans->input, 74, 64);
                    $to = "0x" . substr($trans->input, 34, 40);
                    //按事务散列返回事务的接收。
                    $sts = $CoinClient->eth_getTransactionReceipt($trans->hash);
                    $sts_s = $this->object_array($sts);
                    $sts = substr($sts_s['status'], 2, 1);
                    //判断区块上面的转入状态,status = 0 失败,  logs为空 失败
                    if ($sts != 1 || !$sts_s['logs']) {
    //                    echo 'fail' . "<br>";
                        continue;
                    }
                    // if(in_array($to,$dz_arr)){
                    $userData = Db::name('user_coin')->field("agent_id,ethp")->where(['dyxb' => $to])->find();
                    if(!empty($userData)){
                        $true_amount = $CoinClient->real_banlance_token($CoinClient->decode_hex($value), 8);
                        $zr_info['from_addr'] = $trans->from;
                        $zr_info['user_addr'] = $to;
                        $zr_info['block_number'] = $qb_gd;
                        $zr_info['num'] = $true_amount;
                        $zr_info['hash'] = $trans->hash;
                        $zr_info['type'] = 'dyx';
                        array_push($data, $zr_info);

                        //取出子地址所属商户
                        
                        $agentData = Db::name('coin')->field('token_user,token_pass')->where(['name' => 'eth','agent_id' => $userData['agent_id']])->find();
                        //查询到商户主地址时转入主地址 否则转入钱包主地址
                        $agentAdd = !empty($agentData['token_user']) ? $agentData['token_user'] : $this->Coin['eth']['dj_yh'];
                        $agentPwd = !empty($agentData['token_pass']) ? $agentData['token_pass'] : $this->Coin['eth']['dj_mm'];
                        if($to != $agentAdd){
                            //查询自地址账户eth余额
                            $yue = $CoinClient->eth_getBalance($to);
                            //账户余额少于0.002时 从主账户转入少量ETH作为手续费
                            if ($yue < floatval('0.002')) {
                                //eth转账到token的eth手续费
                                $tradeInfo = [[
                                    'from' => $agentAdd,
                                    'to' => $to,
                                    'gas' => '0x76c0',
                                    'value' => $CoinClient->encode_dec($CoinClient->to_real_value(floatval(0.002 - $yue))),
                                    'gasPrice' => $CoinClient->eth_gasPrice()
                                ]];
                                $sendrs = $CoinClient->eth_sendTransaction($agentAdd, md5($agentPwd.'token'), $tradeInfo);
                                if(isset($sendrs->error)){
                                    $message .= "ETH手续费转账失败：".$sendrs->error->message;
                                }
                            }
                            //将子账户代币余额归集到主账户
                            $call = [
                                'to' => '0x042f972ac93404f0fcbe4e3a0729f0b395232106',
                                'data' => '0x70a08231' . $CoinClient->data_pj($to)
                            ];
                            $num_token = $CoinClient->eth_call($call);
                            $tradeInfo = [[
                                'from' => $to,
                                'to' => '0x042f972ac93404f0fcbe4e3a0729f0b395232106',
                                'data' => '0xa9059cbb' . $CoinClient->data_pj($agentAdd, $num_token),
                            ]];
                            $sendrs = $CoinClient->eth_sendTransaction($to,md5($userData['ethp'].'token') , $tradeInfo);
                            if(isset($sendrs->error)){
                                $message .= "DYX归集失败：".$sendrs->error->message;
                            }
                        }
                    }
                }
                // }
            }

            if (empty($data)) {
                return ['status' => 200, 'json' => $json, 'message' => '轮训成功，无匹配记录', 'data' => ''];
            } else {
                file_put_contents('/tmp/coin/coinRecharge.log', date("Y-m-d H:i:s",time()).',blockNumber:'.$qb_gd.',message:'.$message.',data:'.json_encode($data)."\n\n",FILE_APPEND|LOCK_EX);
                return ['status' => 200, 'json' => $json, 'message' => '转入成功', 'data' => $data];
            }
    }

    //eth 代币转出
    public function coinWithdraw($coin,$addr,$num,$agent_id){
        try{
            //获取代币信息
            $Coin = $this->Coin[$coin];
            //以太坊代币转出操作
            if ($Coin['type'] == 'eth' || $Coin['type'] == 'token') {

                $CoinClient = new EthClient($Coin['dj_zj'], $Coin['dj_dk']);

                $json = $CoinClient->eth_blockNumber(true);

                if (empty($json) || $json <= 0) {
                    return ['status' => 402, 'message' => '钱包连接失败！'];
                }

                $valid_res = strpos($addr, '0x') === 0 ? true : false;
                if (!$valid_res || strlen($addr) < 10) {
                    return ['status' => 406, 'message' => $addr . '不是一个有效的钱包地址！'];
                }

                //获取商户账号信息
                $agentAddr = Db::name('coin')->field('token_user,token_pass')->where(['name' => 'eth','agent_id' => $agent_id])->find();
                $toAddress = !empty($agentAddr['token_user']) ? $agentAddr['token_user'] : $Coin['dj_yh'];
                $passWord = !empty($agentAddr['token_pass']) ? $agentAddr['token_pass'] : $Coin['dj_mm'];

                //转出地址密码
                if($Coin['type'] == 'eth'){
                    $banlance = $CoinClient->eth_getBalance($toAddress);
                    if ($banlance < $num) {
                        return ['status' => 405, 'message' => 'ETH钱包余额不足', 'num' => $num, 'banlance' => $banlance];
                    }
                }elseif ($Coin['type'] == 'token'){
                    $call = [
                        'to' => $Coin['token_address'],
                        'data' => '0x70a08231'.$CoinClient->data_pj($toAddress)
                    ];
                    $sum = $CoinClient->real_banlance_token($CoinClient->decode_hex($CoinClient->eth_call($call)) , $Coin['decimals']);
                    if ($sum < $num) {
                        return ['status' => 406, 'message' => 'token钱包余额不足', 'num' => $num, 'banlance' => $sum];
                    }
                }

                if ($Coin['type'] == 'token') {
                    $value = $CoinClient->encode_dec($CoinClient->to_real_value_token(floatval($num), $Coin['decimals']));
                    $tradeInfo = [[
                        'from' => $toAddress,
                        'to' => $Coin['token_address'],
                        'data' => '0xa9059cbb' . $CoinClient->data_pj($addr, $value),
                    ]];
                    $sendrs = $CoinClient->eth_sendTransaction($toAddress, md5($passWord.'token'), $tradeInfo);
                    // $sendrs = $CoinClient->eth_sendTransaction($toAddress, $passWord, $tradeInfo);
                } elseif ($Coin['type'] == 'eth') {
                    $tradeInfo = [[
                        'from' => $toAddress,
                        'to' => $addr,
                        'gas' => '0x76c0',
                        'value' => $CoinClient->encode_dec($CoinClient->to_real_value(floatval($num))),
                        'gasPrice' => $CoinClient->eth_gasPrice()
                    ]];
                    $sendrs = $CoinClient->eth_sendTransaction($toAddress, md5($passWord.'token'), $tradeInfo);
                    // $sendrs = $CoinClient->eth_sendTransaction($toAddress, $passWord, $tradeInfo);
                }
                file_put_contents('/tmp/coin/coinWithdraw.log', date("Y-m-d H:i:s",time()).',coin:'.$coin.',num:'.$num.',addr:'.$addr.',sendrs:'.json_encode($sendrs)."\n\n",FILE_APPEND|LOCK_EX);
                return ['status' => 200, 'message' => '转币成功！', 'sendrs' => $sendrs];
            }
        }catch(\Exception $e){
            $this->json(['status' => 407, 'message' => $e->getMessage().'->'.$e->getline()]);
        }
    }

    //查询商户主地址余额
    public function getAgentBalance($coin,$agentAddr){
        try{
            //获取代币信息
            $Coin = $this->Coin[$coin];
            $CoinClient = new EthClient($Coin['dj_zj'], $Coin['dj_dk']);
            //获取钱包高度
            $json = $CoinClient->eth_blockNumber(true);

            if (empty($json) || $json <= 0) {
                return ['status' => 402, 'message' => '钱包连接失败！'];
            }
            //以太坊主地址账户余额
            if($Coin['type'] == 'eth'){
                $sum = $CoinClient->eth_getBalance($agentAddr);
                
            }elseif ($Coin['type'] == 'token'){
                $call = [
                    'to' => $Coin['token_address'],
                    'data' => '0x70a08231'.$CoinClient->data_pj($agentAddr)
                ];
                $sum = $CoinClient->real_banlance_token($CoinClient->decode_hex($CoinClient->eth_call($call)) , $Coin['decimals']);
            }
            return ['status' => 200, 'message' => '查询成功', 'sum' => $sum];
        }catch(\Exception $e){
            $this->json(['status' => 407, 'message' => $e->getMessage()]);
        }
    }
    //商户手动归集处理
    public function agentNotionalPooling($coin,$num,$from_addr,$to_addr){
        try{
            //获取代币信息
            $Coin = $this->Coin[$coin];
            $CoinClient = new EthClient($Coin['dj_zj'], $Coin['dj_dk']);
            //获取钱包高度
            $json = $CoinClient->eth_blockNumber(true);

            if (empty($json) || $json <= 0) {
                return ['status' => 402, 'message' => '钱包连接失败！'];
            }
            if ($Coin['type'] == 'token') {
                $value = $CoinClient->encode_dec($CoinClient->to_real_value_token(floatval($num), $Coin['decimals']));
                $tradeInfo = [[
                    'from' => $toAddress,
                    'to' => $Coin['token_address'],
                    'data' => '0xa9059cbb' . $CoinClient->data_pj($addr, $value),
                ]];
                // $sendrs = $CoinClient->eth_sendTransaction($toAddress, md5($passWord.'token'), $tradeInfo);
                $sendrs = $CoinClient->eth_sendTransaction($toAddress, $passWord, $tradeInfo);
            } elseif ($Coin['type'] == 'eth') {
                $tradeInfo = [[
                    'from' => $from_addr,
                    'to' => $to_addr,
                    'value' => $CoinClient->encode_dec($CoinClient->to_real_value(floatval( $num - 0.002))),
                ]];
                $sendrs = $CoinClient->eth_sendTransaction($trans->to, md5($userData['ethp'].'token') , $tradeInfo);
                // $sendrs = $CoinClient->eth_sendTransaction($toAddress, md5($passWord.'token'), $tradeInfo);
                $sendrs = $CoinClient->eth_sendTransaction($toAddress, $passWord, $tradeInfo);
            }
        }catch(\Exception $e){
            $this->json(['status' => 407, 'message' => $e->getMessage()]);
        }
    }
    //导入生成的公钥 私钥 生成地址
    public function importPrivateKey($PrivateKey,$passWord){
        try{
            $Coin = $this->Coin['eth'];
            $CoinClient = new EthClient($Coin['dj_zj'], $Coin['dj_dk']);
            //获取钱包高度
            $json = $CoinClient->eth_blockNumber(true);

            if (empty($json) || $json <= 0) {
                return ['status' => 402, 'message' => '钱包连接失败！'];
            }
            $sendrs = $CoinClient->personal_importRawKey($PrivateKey,$passWord);
            if(isset($sendrs->error)){
                return ['status' => 400,'message' => $sendrs->error->message];
            }else{
                return ['status' => 200,'message' => 'success','data' => $sendrs];
            }
        }catch(\Exception $e){
            $this->json(['status' => 407, 'message' => $e->getMessage()]);
        }
    }
}