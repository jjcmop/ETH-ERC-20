<?php
namespace app\crontab\command;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;
use think\Db;
use app\api\controller\Crontab;
class CoinGuiJi extends Command
{
    protected function configure()
    {
        $this->setName('CoinGuiJi')
            ->setDescription('定时计划：每10秒处理一次手动归集消息');
    }
 
    protected function execute(Input $input, Output $output)
    {
        $ethCrontab = new Crontab();
        $ethCrontab->amqpGetAgentNotionalPooling();
    }
 
}