<?php
namespace app\crontab\command;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;
use think\Db;
use app\api\controller\Crontab;
class CoinReturn extends Command
{
    protected function configure()
    {
        $this->setName('CoinReturn')
            ->setDescription('定时计划：每五分钟发送充值提现订单广播');
    }
 
    protected function execute(Input $input, Output $output)
    {
        $ethCrontab = new Crontab();
        $ethCrontab->publish_return_coin_withdraw();
        $ethCrontab->publish_coin_recharge();
    }
 
}