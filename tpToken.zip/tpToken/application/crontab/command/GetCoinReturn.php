<?php
namespace app\crontab\command;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;
use think\Db;
use app\api\controller\Crontab;
class GetCoinReturn extends Command
{
    protected function configure()
    {
        $this->setName('GetCoinReturn')
            ->setDescription('定时计划：每五秒钟消费充值提现订单广播');
    }
 
    protected function execute(Input $input, Output $output)
    {
        $ethCrontab = new Crontab();
        $ethCrontab->consumer_return_coin_withdraw();
        $ethCrontab->consumer_coin_recharge();
    }
 
}