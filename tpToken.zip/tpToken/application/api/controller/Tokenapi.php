<?php
namespace app\api\controller;
use think\Controller;
use My\DataReturn;
use app\common\Mapi\Walletadd;
use app\common\Mapi\Wallet;
use app\api\model\UserCoinModel;
use app\api\model\AgentModel;
use think\Db;
use think\Config;
use BitWasp\Bitcoin\Crypto\Random\Random;
use BitWasp\Bitcoin\Mnemonic\Bip39\Bip39Mnemonic;
use BitWasp\Bitcoin\Mnemonic\MnemonicFactory;
use app\common\RabbitMQ\RabbitPublish;
use app\common\controller\RedisLib;
class Tokenapi extends Apibase
{
    //商户生成RSA公钥和私钥
    public function registerAgent(){
        Db::startTrans();
        try{
            $data = $this->_data;
            if(!isset($data['name'])){
                DataReturn::returnJson(311,'商户名称不得为空');
            }
            if(!isset($data['app_key'])){
                DataReturn::returnJson(312,'app_key不得为空');
            }
            $appKey = explode("-",$data['app_key']);
            if(count($appKey) != 5 || strlen($appKey[0]) !=8 || strlen($appKey[4]) != 12){
                DataReturn::returnJson(314,'app_key格式错误');
            }
            if(!isset($data['secret_key'])){
                DataReturn::returnJson(313,'secret_key不得为空');
            }
            $secretKey = explode("-",$data['secret_key']);
            if(count($secretKey) != 5 || strlen($secretKey[0]) !=8 || strlen($secretKey[4]) != 12){
                DataReturn::returnJson(315,'secret_key格式错误');
            }
            if(!isset($data['coin_passwd'])){
                DataReturn::returnJson(321,'请输入主流币使用密码');
            }
            if (strlen($data['coin_passwd']) < 6 || strlen($data['coin_passwd']) > 16){
                DataReturn::returnJson(322,'密码格式错误!');
            }
            $random = new Random();
            // 生成随机数(initial entropy)
            $entropy = $random->bytes(Bip39Mnemonic::MIN_ENTROPY_BYTE_LEN);
            $bip39 = MnemonicFactory::bip39();
            // 通过随机数生成助记词
            $mnemonic = $bip39->entropyToMnemonic($entropy);
            $mnemonic = preg_replace("/(\n)|(\s)|(\t)|(\')|(')|(，)/", ',', $mnemonic); 
            $creData = [
                'agent_name'    =>  $data['name'],
                'private_key'   =>  $data['app_key'],
                'secret_key'    =>  $data['secret_key'],
                'mnemonic'      =>  $mnemonic,
                'md5_mnemonic'  =>  md5($mnemonic),
                'coin_passwd'   =>  $data['coin_passwd']
            ];
            $passWord = md5($data['coin_passwd']);
            $agentModel = new AgentModel();
            //检查是否有注册过
            $info = $agentModel->getAgent(['private_key' => $data['app_key']]);
            if(!empty($info)){
                DataReturn::returnJson(407,"商户已注册,请勿重复注册");
            }
            $rel = $agentModel->addAgent($creData);
            $error = 0;	
            $userCoin = [];
            //商户生成主地址并开通主要币种
            //取出以开通的主流币
            $mainCoin = Db::name('coin')->where(['is_main' => 1])->field('name,type,coin_type,title,block_num')->order("id ASC")->select();
            //为商户生成主地址
            $Mapi = new walletAdd();
            $coinData = $Mapi->getUserAddress('eth',$passWord);
    	    foreach ($mainCoin as $key => $val) {
    			if($coinData['status'] === 200){
                    switch ($val['type']) {
                        case 'eth':
                            
                            $userCoin['ethb'] = $coinData['qianbao'];
                            $userCoin['ethp'] =  $passWord;
                            //添加商户主要币种
                            $DataArr = [
                                'name'      =>  $val['name'],
                                'type'      =>  $val['type'],
                                'is_main'   =>  0,
                                'coin_type' =>  $val['coin_type'],
                                'title'     =>  $val['title'],
                                'block_num' =>  $val['block_num'],
                                'token_user'=>  $coinData['qianbao'],
                                'token_pass'=>  $passWord,
                                'status'    =>  1,
                                'agent_id'  =>  $rel
                            ];
                            Db::name('coin')->insert($DataArr);
                            //添加商户地址到用户列表
            			    $userCoinData = [
                        		'agent_id'      =>  $rel,
                        		'username'      =>  $data['name'],
                        		'qianbao'       =>  $userCoin['ethb'],
                        		'password'      =>  $userCoin['ethp']
                		    ];
                		    $UserCoinModel = new UserCoinModel;
                		    $UserCoinModel->addUserCoin($userCoinData);
                            
                            break;
                        case 'token':
                            //添加代币
    						$DataArr = [
                                'name'      =>  $val['name'],
                                'type'      =>  $val['type'],
                                'is_main'   =>  0,
                                'coin_type' =>  $val['coin_type'],
                                'title'     =>  $val['title'],
                                'block_num' =>  $val['block_num'],
                                'token_user'=>  $coinData['qianbao'],
                                'token_pass'=>  $passWord,
                                'status'    =>  1,
                                'agent_id'  =>  $rel
                            ];
                            Db::name('coin')->insert($DataArr);
    						break;
                        default:
                            break;
                    }
                }else{
    			    $error = 1;	
    			}
    		}
    	    if($error == 1){
        		Db::rollback();
        		DataReturn::returnJson(1,'error');
    	    }else{
        		Db::commit();
        		DataReturn::returnJson(0,'success',['mnemonic' => $mnemonic]);
    	    }
        }catch(\Exception $e){
            Db::rollback();
            DataReturn::returnJson(400,$e->getMessage().'->'.$e->getFile().'->'.$e->getline());
        }
    }
    //用户生成及获取钱包地址接口
    public function getUserAddress()
    {
    	try{
    		$data=$this->_data;
            if (!isset($data['coin'])){
                DataReturn::returnJson(304,'币种名称不得为空');
            }
            if (!in_array($data['coin'], ['eth','usdt','dyx'])) {
                DataReturn::returnJson(305,'无效的币种系列');
            }
            
            if(!isset($data['username'])){
                DataReturn::returnJson(306,'用户名不得为空');
            }
            $Coin = Config::get('COIN');
            $userModel = new UserCoinModel();
            $agent = $this->_agent;
            $userInfo = $userModel->getUserInfo(['agent_id'=>$agent['id'],'username'=>$data['username']]);
            // //币种地址字段名称
            $coinField = $data['coin'].'b';

            if(!empty($userInfo) && $userInfo[$coinField]){
                $qianbao = $userInfo[$coinField];
            }else{
                if($Coin[$data['coin']]['type'] == 'eth' || $Coin[$data['coin']]['type'] == 'token'){
                    //未创建用户信息时 先创建用户信息 并生成以太坊地址
                    if(empty($userInfo)){
                        $Mapi = new walletAdd();
                        $coinData = $Mapi->getUserAddress('eth',md5($data['username']));
                        if($coinData['status'] === 200){
                            $qianbao = $coinData['qianbao'];
                            $addData = ['username' => $data['username'], 'agent_id' => $agent['id'], 'password' => md5($data['username']), 'qianbao' => $qianbao];
                            $userModel->addUserCoin($addData);
                            $userInfo = $userModel->getUserInfo(['agent_id'=>$agent['id'],'username'=>$data['username']]);
                        }else{
                            DataReturn::returnJson(400,$coinData['message']);
                        }     
                    }else{
                        //有用户信息时 以太坊地址为空时 创建用户以太坊地址
                        if(empty($userInfo['ethb'])){
                            $Mapi = new walletAdd();
                            $coinData = $Mapi->getUserAddress($data['coin'],$data['username']);
                            if($coinData['status'] === 200){
                                $qianbao = $coinData['qianbao'];
                                $userModel->editUserCoin(['id' => $userInfo['id']],['ethb' => $qianbao]);
                                $userInfo = $userModel->getUserInfo(['agent_id'=>$agent['id'],'username'=>$data['username']]);
                            }else{
                                DataReturn::returnJson(400,$coinData['message']);
                            }
                        }
                    }
                     //以太坊代币地址与以太坊共用
                    if($Coin[$data['coin']]['type'] == 'token'){
                        if(empty($userInfo[$coinField])){
                            $qianbao = $userInfo['ethb'];
                            $userModel->editUserCoin(['id' => $userInfo['id']],[$coinField => $qianbao]);
                        }
                    } 
                }
            }
            $data = ['address' => $qianbao];
	        DataReturn::returnJson(0,'success',$data);
    	}catch(\Exception $e){
            DataReturn::returnJson(400,$e->getMessage());
    	}
    }
    //用户生成及获取钱包地址接口
    public function newGetUserAddress()
    {
        try{
            $data=$this->_data;
            if (!isset($data['coin'])){
                DataReturn::returnJson(304,'币种名称不得为空');
            }
            if (!in_array($data['coin'], ['eth','usdt','dyx'])) {
                DataReturn::returnJson(305,'无效的币种系列');
            }
            
            if(!isset($data['username'])){
                DataReturn::returnJson(306,'用户名不得为空');
            }
            $Coin = Config::get('COIN');
            $userModel = new UserCoinModel();
            $agent = $this->_agent;
            $userInfo = $userModel->getUserInfo(['agent_id'=>$agent['id'],'username'=>$data['username']]);
            // //币种地址字段名称
            $coinField = $data['coin'].'b';

            if(!empty($userInfo) && $userInfo[$coinField]){
                $qianbao = $userInfo[$coinField];
                $mnemonic = $userInfo['mnemonic'];
            }else{
                if($Coin[$data['coin']]['type'] == 'eth' || $Coin[$data['coin']]['type'] == 'token'){
                    //未创建用户信息时 先创建用户信息 并生成以太坊地址
                    if(empty($userInfo)){
                        $Mapi = new Wallet();
                        $result = $Mapi->createAddress();
                        if($result['status'] === 200){
                            $coinData = json_decode($result['data'],true);
                            $qianbao = $coinData['address'];
                            $mnemonic = $coinData['mnemonic'];
                            $addData = ['username' => $data['username'], 'agent_id' => $agent['id'], 'password' => $coinData['password'], 'qianbao' => $qianbao,'mnemonic' => $coinData['mnemonic']];
                            $userModel->addUserCoin($addData);
                            $userInfo = $userModel->getUserInfo(['agent_id'=>$agent['id'],'username'=>$data['username']]);
                        }else{
                            DataReturn::returnJson(400,$coinData['message']);
                        }     
                    }else{
                        //有用户信息时 以太坊地址为空时 创建用户以太坊地址
                        if(empty($userInfo['ethb'])){
                            $Mapi = new Wallet();
                            $result = $Mapi->createAddress();
                            if($result['status'] === 200){
                                $coinData = json_decode($result['data'],true);
                                $qianbao = $coinData['address'];
                                $mnemonic = $coinData['mnemonic'];
                                $userModel->editUserCoin(['id' => $userInfo['id']],['ethb' => $qianbao,'mnemonic' => $coinData['mnemonic']]);
                                $userInfo = $userModel->getUserInfo(['agent_id'=>$agent['id'],'username'=>$data['username']]);
                            }else{
                                DataReturn::returnJson(400,$coinData['message']);
                            }
                        }
                    }
                     //以太坊代币地址与以太坊共用
                    if($Coin[$data['coin']]['type'] == 'token'){
                        if(empty($userInfo[$coinField])){
                            $qianbao = $userInfo['ethb'];
                            $mnemonic = $userInfo['mnemonic'];
                            $userModel->editUserCoin(['id' => $userInfo['id']],[$coinField => $qianbao]);
                        }
                    } 
                }
            }
            $data = [
                'address' => $qianbao,
                'mnemonic'=> $mnemonic
            ];
            DataReturn::returnJson(0,'success',$data);
        }catch(\Exception $e){
            DataReturn::returnJson(400,$e->getMessage());
        }
    }
    //转入数据查询
    public function getCoinInchange(){
        try{
            $data = $this->_data;
            $agent = $this->_agent;
            //以分页的形式返回各商户的转入数据
            $page = $data['page'] ? $data['page'] : 0;
            $limit = $data['limit'] ? $data['limit'] : 15;
            $coinList = Db::name('myzr')->where(['agent_id' => $agent['id']])->field('addtime,block_number,coinname,from_address,to_address,num,hash')->page($page,$limit)->order('id ASC')->select();
            $data = ['page' => $page, 'list' => $coinList];
            DataReturn::returnJson(0,'success',$data);
        }catch(\Exception $e){
            DataReturn::returnJson(400,$e->getMessage());
        }
    }
    //提现记录查询
    public function getcoinWithdrawList(){
        try{
            $data = $this->_data;
            $agent = $this->_agent;
            //以分页的形式返回各商户的转入数据
            $page = $data['page'] ? $data['page'] : 0;
            $limit = $data['limit'] ? $data['limit'] : 15;
            $coinList = Db::name('myzc')->where(['agent_id' => $agent['id']])->field('addtime,coinname,from_address,to_address,num')->page($page,$limit)->order('id ASC')->select();
            $data = ['page' => $page, 'list' => $coinList];
            DataReturn::returnJson(0,'success',$data);
        }catch(\Exception $e){
            DataReturn::returnJson(400,$e->getMessage());
        }
    }
    //转出
    public function coinWithdraw(){
        // Db::startTrans();
        try {
            $data = $this->_data;
            $agent = $this->_agent;
            $Coin = Config::get('COIN');
            if(!isset($data['coin'])){
                DataReturn::returnJson(304,'币种名称不得为空');
            }
            if (!in_array($data['coin'], ['eth','usdt','dyx'])) {
                DataReturn::returnJson(305,'无效的币种系列');
            }
            if(!isset($data['from_addr'])){
                DataReturn::returnJson(307,'转出地址不得为空');
            }
            $userModel = new UserCoinModel();
            $User = $userModel->getUserInfo([$data['coin'].'b' => $data['from_addr']]);
            if(empty($User) || $User['agent_id'] != $agent['id']){
                DataReturn::returnJson(308,'无效的用户地址');
            }
            if(!isset($data['to_addr'])){
                DataReturn::returnJson(309,'提现地址不得为空');
            }
            if($data['num'] < 0){
                DataReturn::returnJson(310,'提现数量错误');
            }
            
            $is_check = Db::name('myzc')->field('id')->where(['serial_number' => $data['serialNumber']])->find();
            if(!empty($is_check)){
                DataReturn::returnJson(328,'订单号重复');
            }
            $redislib = new RedisLib();
            $checkRedis = $redislib->hExists('coin_withdraw',$data['serialNumber']);
            if($checkRedis){
                DataReturn::returnJson(328,'订单待处理，勿重复提交');
            }
            if($Coin[$data['coin']]['type'] == 'eth' || $Coin[$data['coin']]['type'] == 'token'){
                //订单号存入redis 防止提现订单重复  
                $redislib->hSet('coin_withdraw',$data['serialNumber'],time());
                $rabData = $data;
                $rabData['agent_id'] = $agent['id'];
                $rabData['user_id'] = $User['id'];
                $rabData['username'] = $User['username'];
                $publish = new RabbitPublish();
                $publish->amqp_publish_msg_fanout($rabData,"coin_withdraw");
                DataReturn::returnJson(0,'success');
            }    
        } catch (\Exception $e) {
            DataReturn::returnJson(400,$e->getMessage().'->'.$e->getline());
        }
    }
    //获取币种配置信息
    public function getCoinList(){
        try{
            $data = $this->_data;
            $agent = $this->_agent;
            $page = $data['page'] ? $data['page'] : 0;
            $limit = $data['limit'] ? $data['limit'] : 15;
            $coinList = Db::name('coin')->field("name,coin_type,type,CONCAT(coin_type,'_',name,'_',token_user) as coin_type,status")->where(['agent_id' => $agent['id']])->page($page,$limit)->select();
            $data = ['page' => $page, 'list' => $coinList];
            DataReturn::returnJson(0,'success',$data);
        }catch(\Exception $e){
            DataReturn::returnJson(400,$e->getMessage());
        }
    }
    //获取商户下用户信息
    public function getAgentUser(){
        try{
            $data = $this->_data;
            $agent = $this->_agent;
            $page = $data['page'] ? $data['page'] : 0;
            $limit = $data['limit'] ? $data['limit'] : 15;
            $list = Db::name('user_coin')->where(['agent_id' => $agent['id']])->page($page,$limit)->select();
            $userList = [];
            foreach ($list as $key => $val) {
                $userList[$key] = [
                    'username'  =>  $val['username'],
                    'add_time'  =>  $val['add_time'],
                    'coin'      =>  [[
                        'coinname'  =>  'eth',
                        'num'       =>  $val['eth'],
                        'address'   =>  $val['ethb']
                    ],[
                        'coinname'  =>  'usdt',
                        'num'       =>  $val['usdt'],
                        'address'   =>  $val['usdtb']
                    ],[
                        'coinname'  =>  'dyx',
                        'num'       =>  $val['dyx'],
                        'address'   =>  $val['dyxb']
                    ]]
                ];
            }
            $data = ['page' => $page, 'list' => $userList];
            DataReturn::returnJson(0,'success',$data);
        }catch(\Exception $e){
            DataReturn::returnJson(400,$e->getMessage());
        }
    }
    //获取主账户余额
    public function getAgentBalance(){
        try{
            $data = $this->_data;
            $agent = $this->_agent;
            if(!isset($data['coin_type'])){
                DataReturn::returnJson(316,'coin_type为空');
            }
            $CoinData = explode("_",$data['coin_type']);
            $coin = strtolower($CoinData[0]);
            $name = strtolower($CoinData[1]);
            $address = $CoinData[2];
            if(!isset($coin) || !isset($name) || !isset($address)){
                DataReturn::returnJson(317,'coin_type信息有误');
            }
            //查询商户有没有开通币种
            $userCoin = Db::name('coin')->where(['agent_id' => $agent['id'],'name' => $name])->find();
            if(empty($userCoin) || $userCoin['status'] == 0){
                DataReturn::returnJson(318,'商户未开通此币种');
            }
            if($address != $userCoin['token_user']){
                DataReturn::returnJson(319,'商户合约地址有误');
            }
            $Mapi = new walletAdd();
            $result = $Mapi->getAgentBalance($name,$address);
            if($result['status'] == 200){
                DataReturn::returnJson(0,'success',['balance' => $result['sum']]);
            }else{
                DataReturn::returnJson(404,$result['message']);
            }
        }catch(\Exception $e){
            DataReturn::returnJson(400,$e->getMessage().'->'.$e->getline());
        }
    }

    //商户归集
    public function agentNotionalPooling(){
        try{
            $data = $this->_data;
            $agent = $this->_agent;
            if(!isset($data['mnemonic'])){
                DataReturn::returnJson(323,'助记词不得为空');
            }
            if(!isset($data['password'])){
                DataReturn::returnJson(324,'账户密码不得为空');
            }
            //验证助记词
            if($agent['md5_mnemonic'] != md5($data['mnemonic'])){
                DataReturn::returnJson(325,'助记词验证失败');
            }
            //查询开通的币种
            $coinData = Db::name("coin")->field("name,token_user,token_pass")->where(['agent_id' => $agent['id'],'status' => 1])->select();
            //查询商户的所有用户
            $agentUser = Db::name("user_coin")->where("agent_id = '".$agent['id']."' AND ethb <> '".$coinData[0]['token_user']."' AND ( usdt > 0 OR dyx > 0 OR eth > 0 )")->select();
            if(empty($agentUser)){
                DataReturn::returnJson(326,'未查询到可归集的子账户');
            }
            $this->publish = new RabbitPublish();
            foreach ($coinData as $key => $val) {
                //插入归集申请订单
                $logID = Db::name('agent_log')->insertGetId(['agent_key' => $agent['private_key'],'coinname' => $val['name'],'address' => $val['token_user'],'addtime' => time()]);
                foreach ($agentUser as $k => $v) {
                    if($v[$val['name'].'b'] != $val['token_user'] && $v[$val['name']] > 0){
                        $data = [
                            'agent_key' =>  $agent['private_key'],
                            'coin'      =>  $val['name'],
                            'agentAddr' =>  $val['token_user'],
                            'agentPass' =>  $val['token_pass'],
                            'userAddr'  =>  $v[$val['name'].'b'],
                            'userPass'  =>  $v['ethp'],
                            'log_id'    =>  $logID
                        ];
                        $this->publish->amqp_publish_msg_fanout($data,"agentNotionalPooling");
                    }
                }
            }
            DataReturn::returnJson(0,'success');
        }catch(\Exception $e){
            DataReturn::returnJson(400,$e->getMessage());
        }
    }
}
