<?php
namespace app\api\controller;
use think\Controller;
use My\DataReturn;
use app\common\controller\RedisLib;
use app\api\model\AgentModel;
use app\common\Sign\rsa;
use app\common\Sign\aes;
use app\common\Curl\Curl;
class Apibase extends Controller
{
	protected $_data=[];		//接口数据
    protected $_agent=[];       //商户数据
    protected $key = '';        //
    protected $iv = "ZZWBKJ_ZHIHUAWEI";
    protected $apiNum = 100; //单个接口每分钟调用次数
	public function _initialize(){
		header("Content-Type:text/html; charset=utf-8");	//设置程序编码
		header('Access-Control-Allow-Origin:*');  			// 指定允许其他域名访问
		header('Access-Control-Allow-Methods:GET,POST,OPTIONS');  	// 响应类型  
		header('Access-Control-Allow-Headers:x-requested-with,content-type,Authorization,userId');
		header('Access-Control-Expose-Headers:Authorization,userId');
		header('Access-Control-Allow-Credentials: true');
		if(request()->isOptions()){
			header("HTTP/1.1 200 Ok");
			exit;
		}
		$this->_doData();	//参数处理
		// $this->redislib = new RedisLib();
	}
	//作用：1、获取用户访问的模块、控制器、操作，2、将传递过来的json数据转化成数组，
	private function _doData(){
		$action = strtoupper(request()->action());	//获取访问的操作
		$minActList=[						// 
				'GETUSERADDRESS',
                'GETCOININCHANGE',
                'COINWITHDRAW',		//
                'GETCOINWITHDRAWLIST',
                'GETCOINLIST',
                'GETAGENTUSER',
                'REGISTERAGENT',
                'GETAGENTBALANCE',
                'AGENTNOTIONALPOOLING'
			];
        //redis限制接口请求次数
		$this->RestrictionRedis($action);

        // $json = file_get_contents("php://input");

		// $json=$this->request->post('data','','htmlspecialchars_decode');
		// $json=$this->request->post('data/a');
        $json = $this->request->param(''); 
		// $data=json_decode($json['data'],true);
        if(!isset($json['data'])){
            DataReturn::returnJson(400,'接口参数为空');
        }   // 
        $data = $json['data'];   // 
        $this->key = isset($data['secret_key']) ? $data['secret_key'] : '';
        if($action != 'REGISTERAGENT'){
            //检测商户秘钥
            if (!isset($data['agent_key'])) {
                DataReturn::returnJson(300,'商户秘钥为空');
            }
            $agentModel = new AgentModel();

            $agent = $agentModel->getAgent(['private_key'=>$data['agent_key']]);

            if(empty($agent)){
                DataReturn::returnJson(301,'无效的商户秘钥');
            }
            //储存商户信息
            $this->_agent = $agent;
            $this->key = $this->_agent['secret_key'];
        }
        //转账接口为AES和RSA验证
        if($action == 'COINWITHDRAW'){
            //取出商户RSA公钥 
            if(empty($agent['pub_key'])){
                //接口调取商户公钥
                $signUrl = "http://token.xcoinpay.io/Api/Api/user_select";
                $resul = Curl::http_curl($signUrl,['app_key' => $data['agent_key']]);
                $result = json_decode($resul,true);
                if($result['code'] == 0){
                    $pub_key  = $result['data']['rsapub'];
                    $file ="http://token.xcoinpay.io".$pub_key;
                    $pem = file_get_contents($file);
                    $agentModel = new AgentModel();
                    $res = $agentModel->editAgent(['id' => $agent['id']],['pub_key' => $pem]);
                    if(!$res){
                        DataReturn::returnJson(500,'商户公钥写入失败');
                    }
                }
            }else{
            	$pem = $agent['pub_key'];
            }

            if(!isset($data['encode'])){
                DataReturn::returnJson(500,'encode参数为空!');
            }
             $rsaObj = new Rsa();
             $rsaObj->init('',$pem,true);
             //首先解密encode
             $encrypt_key = $rsaObj->pub_decode($data['encode']);
             if(!$encrypt_key){
                DataReturn::returnJson(501,'encode解码失败!');
             }
            if(!isset($data['encrypted'])){
                DataReturn::returnJson(502,'encrypted参数为空!');
            }
             //再解密encrypted
             $aesObj = new aes();
             $signData = $aesObj->decryptWithOpenssl($data['encrypted'],$encrypt_key,$this->iv);
             if(!$signData){
                DataReturn::returnJson(503,'encrypted解码失败!');
             }
             $data = json_decode($signData,true);
             $data['serialNumber'] = $encrypt_key;
        }
		$this->_data=$data;
       
		//验证接口权限
		if(!in_array($action, $minActList)){
			// header("HTTP/1.1 404 Limited access to interface!");
			DataReturn::returnJson(404,'接口访问权限受限!');
		}
        
        //获取钱包地址和充值列表验证sign签名
        $sign = $this->MakeSign($data);
        //获取钱包地址/充值提现列表时,使用明文和密文的方式
        if(in_array($action, ['GETUSERADDRESS','GETCOININCHANGE','GETCOINWITHDRAWLIST','GETCOINLIST','GETAGENTUSER','REGISTERAGENT','GETAGENTBALANCE','AGENTNOTIONALPOOLING'])){

            if(!isset($data['sign'])){
                DataReturn::returnJson(504,'sign签名为空');
            }
            if($data['sign'] != $sign){
                DataReturn::returnJson(505,'sign验签有误',$sign);
            }
        }
        
	}

    /**
     * 格式化参数格式化成url参数
     */
    private function ToUrlParams($reqData)
    {
        $buff = "";
        foreach ($reqData as $k => $v)
        {
            if($k != "sign" && $v !== "" && !is_array($v)){
                $buff .= $k . "=" . $v . "&";
                // $buff .= $k . "=" . $v . "";
            }
        }
        
        $buff = trim($buff, "&");
        return $buff;
    }
    
    /**
     * 生成签名
     */
    private function MakeSign($reqData)
    {
        //签名步骤一：按字典序排序参数
        ksort($reqData);
        $string = $this->ToUrlParams($reqData);
        //签名步骤二：在string后加入KEY
        $string = $string . "&secret_key=".$this->key;
        // $string = $string . $this->key;
        //echo $string;
        //签名步骤三：MD5加密
        // return $string;
        $string = md5($string);
        //签名步骤四：所有字符转为大写
        //$result = strtoupper($string);
        return $string;
    }

      /**
     * 获取客户端IP地址
     * @param integer $type 返回类型 0 返回IP地址 1 返回IPV4地址数字
     * @param boolean $adv 是否进行高级模式获取（有可能被伪装）
     * @return mixed
     */
    function get_client_ip($type = 0, $adv = false)
    {
        $type      = $type ? 1 : 0;
        static $ip = null;
        if (null !== $ip) {
            return $ip[$type];
        }

        if ($adv) {
            if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
                $pos = array_search('unknown', $arr);
                if (false !== $pos) {
                    unset($arr[$pos]);
                }

                $ip = trim($arr[0]);
            } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (isset($_SERVER['REMOTE_ADDR'])) {
                $ip = $_SERVER['REMOTE_ADDR'];
            }
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        // IP地址合法验证
        $long = sprintf("%u", ip2long($ip));
        $ip   = $long ? array($ip, $long) : array('0.0.0.0', 0);
        return $ip[$type];
    }
    //Redis限制接口请求次数
    public function RestrictionRedis($action){
        //获取请求方IP地址
        $serverIP = $this->get_client_ip();
        //组装KEY
        $key = $serverIP.'_'.$action;
        $redislib = new RedisLib();
        //取出访问次数
        $listCount = $redislib->lLen($key);
        //访问次数大于等于系统设定次数后
        if($listCount >= $this->apiNum){
            //取出队列第一次访问时的时间戳
            $firstTime = $redislib->lIndex($key,-1);
            //判断第一次访问的时间戳与当前时间是否大于一分钟
            if((time()-$firstTime) > 60){
                //将第一次访问的时间戳弹出
                $redislib->rPop($key);
                //加入当前时间戳
                $redislib->lPush($key,time());
            }else{
                DataReturn::returnJson(506,"单个接口访问超过限制");
            }
        }else{
            $redislib->lPush($key,time());
        }
    }
}