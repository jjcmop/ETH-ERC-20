<?php
namespace app\api\controller;
use think\Controller;
use app\common\controller\Tokenlist;
use think\Db;
use app\common\Curl\Curl;
use My\DataReturn;
use app\common\RabbitMQ\RabbitPublish;
use app\common\RabbitMQ\RabbitConsumer;
use app\common\controller\RabbitMQ;
class Crontab extends Controller
{
	public function __construct(){
		$this->Tokenlist = new Tokenlist();
		$this->publish = new RabbitPublish();
		$this->consumer = new RabbitConsumer();
		$this->RabbitMQ = new RabbitMQ();
	}

	/**
	*   获取节点内用户转入数据
	*
	**/
	public function get_coin_order_info(){
		try{
			$Data = Db::name('coin')->field("name,type,block_num,api_status,err_time")->where(['name' => ['IN',['eth']],'is_main' => 1])->select();

			foreach ($Data as $key => $coinData) {
					//检查接口是否出现异常
				if($coinData['api_status'] == 1){
					//判断接口异常时间 一分钟内 停止发送消息
					if((time()-$coinData['err_time']) < 60){
						file_put_contents('/tmp/coin/coin_err.log', date("Y-m-d H:i:s",time()).'->'.$coinData['type'].'->'.date("Y-m-d H:i:s",$coinData['err_time'])."\n\n",FILE_APPEND|LOCK_EX);
						exit();
					}else{
						Db::name('coin')->where(['type'=>$coinData['type']])->update(['api_status'=>0]);
					}
				}
				
				//获取数据库高度
				$blockNumber = $coinData['block_num'];
				$result = $this->Tokenlist->coin_order_info(['name'=>$coinData['name'],'type'=>$coinData['type'],'Height'=>$blockNumber]);
				if($result['status'] == 200){
					$blockNumber = $blockNumber +1;
					//修改当前eth系列高度
					Db::name('coin')->where(['type'=>$coinData['type']])->update(['block_num'=>$blockNumber]);
					// Db::name('coin')->where(['type'=>$coinData['type']])->setInc('block_num',1);
				}
				echo date("Y-m-d H:i:s",time()).'-->'.$coinData['name'].'-->'.$blockNumber.'-->'.$result['msg']."\n";
			}		
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/coin_crontab_err.log', $e->getMessage()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
	/**
	 *  获取单独节点内转入数据
	 * 
	 */
	public function getBlockNumberToOrder(){
		try{
			$blockNumber = $_GET['blockNumber'];
			if($blockNumber < 0){
				throw new \Exception('区块高度不得为空');
			}
			$result = $this->Tokenlist->BlockNumberToOrder(['name'=>'eth','type'=>'eth','Height'=>$blockNumber]);
			print_r($result);
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/getBlockNumberToOrder.log', $e->getMessage()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
	/**
	 *  提现订单广播发送消息
	 * 
	 */
	public function publish_return_coin_withdraw(){
		try{
			$list = Db::name("myzc")->alias("m")->join("coin c","c.agent_id = m.agent_id AND c.name = m.coinname")->field("m.id,m.serial_number as serialNumber,m.serial_number as uniquekey,m.coinname,m.addtime as createtime,m.num,m.txid,m.to_address as address,CONCAT(UPPER(c.coin_type),'_',UPPER(c.name),'_',c.token_user) as coin_type,'out' as direction,m.status,m.common")->where(['m.is_return' => 0])->select();
			foreach ($list as $key => $val) {
				$this->publish->amqp_publish_msg_fanout($val,"return_coin_withdraw");
			}
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/return_coin_withdraw_err.log', date("Y-m-d H:i:s",time())."-->Crontab:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
	/**
	 *  提现订单广播接收消息
	 * 
	 */
	public function consumer_return_coin_withdraw(){
		try{
			$this->consumer->amqpGetMsgFanout("return_coin_withdraw");
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/return_coin_withdraw_err.log', date("Y-m-d H:i:s",time())."-->Crontab:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
	/**
	 * 	充值订单广播消息发送
	 * 
	 */
	public function publish_coin_recharge(){
		try{
			$list = Db::name("myzr")->alias("m")->join("coin c","c.agent_id = m.agent_id AND c.name = m.coinname")->field("m.id,m.to_address as address,m.num,m.addtime as createtime,m.block_number as blockNumber,m.hash,CONCAT(UPPER(c.coin_type),'_',UPPER(c.name),'_',c.token_user) as coin_type,'in' as direction,m.status,m.common")->where(['m.is_return' => 0])->select();
			foreach ($list as $key => $val) {
				$this->publish->amqp_publish_msg_fanout($val,"coin_recharge");
			}
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/coin_recharge_err.log', date("Y-m-d H:i:s",time())."-->Crontab:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
	/**
	 *  充值订单广播接收消息
	 * 
	 */
	public function consumer_coin_recharge(){
		try{
			$this->consumer->amqpGetMsgFanout("coin_recharge");
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/coin_recharge_err.log', date("Y-m-d H:i:s",time())."-->Crontab:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
	/**
	 * 	商户手动归集
	 * 
	 */
	public function amqpGetAgentNotionalPooling(){
		try{
			$this->consumer->amqpGetMsgFanout("agentNotionalPooling");
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/amqpGetAgentNotionalPooling_err.log', date("Y-m-d H:i:s",time())."-->Crontab:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
	/**
	 * 	批量生成用户地址
	 * 
	 */
	public function amqpGetBatchGetAddress(){
		try{
			$this->consumer->amqpGetMsgFanout("batchGetAddress");
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/amqpGetBatchGetAddress_err.log', date("Y-m-d H:i:s",time())."-->Crontab:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}

	/**
	 * 	用户提现消息消费
	 * 
	 */
	public function amqpGetCoinWithdraw(){
		try{
			$this->consumer->amqpGetMsgFanout("coin_withdraw");
		}catch(\Exception $e){
			file_put_contents('/tmp/coin/amqpGetCoinWithdraw_err.log', date("Y-m-d H:i:s",time())."-->Crontab:".$e->getMessage().'-->'.$e->getFile().'-->'.$e->getline()."\n\n",FILE_APPEND|LOCK_EX);
		}
	}
}