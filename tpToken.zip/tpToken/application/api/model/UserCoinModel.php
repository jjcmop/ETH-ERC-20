<?php
namespace app\api\model;
use think\Model;
class UserCoinModel extends Model
{
	protected $name = 'user_coin';
	/**
	 * 查找单个用户
	 * by LaoHu  2019-10-26
	 */
	public function getUserInfo($map){
		$info = db($this->name)->where($map)->find();
		return $info;
	}
	/**
	 * 添加用户
	 * by LaoHu 2019-10-26
	 */
	public function addUserCoin($map){
		if(!$map['username']){
			return ['status' => 401, 'message' => '用户名不得为空'];
		}
		if(!$map['agent_id']){
			return ['status' => 402, 'message' => '代理商ID不能为空'];
		}
		if(!$map['qianbao']){
			return ['status' => 405, 'message' => '钱包地址不能为空'];
		}
		$data = [];
		$data['username'] = $map['username'];
		$data['agent_id'] = $map['agent_id'];
		$data['ethb'] = $map['qianbao'];
		$data['ethp'] = $map['password'];
		$data['usdtb'] = $map['qianbao'];
		$data['dyxb'] = $map['qianbao'];
		$data['mnemonic'] = $map['mnemonic'];
		$data['add_time'] = time();
		$rel = db($this->name)->insert($data);
		if($rel){
			return ['status' => 200, 'message' => '用户添加成功!'];
		}else{
			return ['status' => 406, 'message' => '参数有误数据添加失败!'];
		}
	}
	/**
	 *	修改用户
	 * 	by LaoHu 2019-11-4
	 */
	public function editUserCoin($map,$data){
		if(empty($map)){
			return ['status' => 401, 'message' => '查询条件不得为空!'];
		}
		$rel = db($this->name)->where($map)->update($data);
		if($rel){
			return ['status' => 200, 'message' => '修改成功!'];
		}else{
			return ['status' => 406, 'message' => '参数有误数据修改失败!'];
		}
	}
}