<?php
namespace app\api\model;
use think\Model;
class AgentModel extends Model
{
	protected $name = 'agent';
	/**
	 * 添加代理商
	 * by LaoHu 2019-10-26
	 */
	public function addAgent($data){
		$rel = db($this->name)->insertGetId($data);
		if($rel){
			return $rel;
		}else{
			return false;
		}
	}

	public function getAgent($map){
		$info = db($this->name)->where($map)->find();
		return $info;
	}


	public function editAgent($map,$data){
		$rel = db($this->name)->where($map)->update($data);
		if($rel){
			return $rel;
		}else{
			return false;
		}
	}
}