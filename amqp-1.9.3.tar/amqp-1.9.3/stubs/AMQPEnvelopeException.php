<?php

/**
 * stub class representing AMQPEnvelopeException from pecl-amqp
 */
class AMQPEnvelopeException extends AMQPException
{
    /**
     * @var AMQPEnvelope
     */
    public $envelope;
}
