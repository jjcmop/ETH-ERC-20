<?php 

phpinfo();
