<?php
/**
 * Created by PhpStorm.
 * User: redstart
 * Date: 2017/10/12
 * Time: 16:14
 */
namespace Admin\model;
use ext\Model;

class User_model extends Model
{

}